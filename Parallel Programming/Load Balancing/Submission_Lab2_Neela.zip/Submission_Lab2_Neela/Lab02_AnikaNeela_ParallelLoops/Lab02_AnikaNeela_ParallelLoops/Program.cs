﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace Lab02_AnikaNeela_ParallelLoops
{
    class Program
    {
        const int times = 10000;
        static double[] x = new double[times];
        static int cores = Environment.ProcessorCount;

        static void ProcessElement(double e)
        {
            for (int i = 0; i < e; i++)
            {
                e = (double)(e * Math.Sqrt(Math.Cos(1.0 / (e + 1)) +
                Math.Sin(1.0 / (e + 1))));
            }

        }

        static void ProcessArray()
        {
            for (int i = 0; i < times; i++)
            {
                ProcessElement(x[i]);
            }
        }

        static void ProcessArrayParallelFor()
        {
            Parallel.For(0, times, (int i) =>
            {
                //Console.WriteLine("i: " + i);
                ProcessElement(x[i]);
            });
        }

        static void ProcessArrayChunkParallelFor()
        {
            Parallel.For(0, cores, (int chunk) =>
            {
                //Console.WriteLine("Percentage of Work for Chunk" + chunk + " " + Math.Round(((double)(((chunk+1)*times^2)/(2*cores))/times)*100, 2) + "%");
                //Console.WriteLine("Chunk number for ProcessArrayChunkParallelFor(): " + chunk);
                int chunkSize = (int)(times / cores) + 1;
                for (int i = chunk * chunkSize; i < (chunk + 1) * chunkSize && i < times; i++)
                {
                    // Console.WriteLine("Index number for ProcessArrayChunkParallelFor(): " + i);
                    ProcessElement(x[i]);
                }
            }
            );
        }

        static void BalancedChunksParallelFor()
        {
            Parallel.For(0, cores, (int chunk) =>
            {
                double from = times* Math.Pow(chunk, 1/2.0);
                double to = (times * (Math.Pow((chunk + 1), 1 / 2.0))/ cores);
                for (double i = from; i < to && i < times; i++)
                    ProcessElement(x[(int)i]);
            }
            );
        }

        static void ProcessArrayRoundRobinParallelFor()
        {
            Parallel.For(0, cores,
            (seed) =>

            {
                // Console.WriteLine("Seed: " + seed);
                for (int i = seed; i < times; i += cores) //i+= cores is the magic for robin
                {
                    // Console.WriteLine("i:" + i);
                    ProcessElement(x[i]);
                }
            });
        }


        static void Main(string[] args)
        {
            Console.WriteLine("Starting sequential task!");
            var sw = Stopwatch.StartNew();
            ProcessArray();
            TimeSpan sequential = sw.Elapsed;
            Console.WriteLine("\nSequentialtask ended! Duration: " + sequential.ToString());

            Console.WriteLine("Starting Parallel.For task!");
            sw = Stopwatch.StartNew();
            ProcessArrayParallelFor();
            TimeSpan parallelFor = sw.Elapsed;
            Console.WriteLine("\nParallel.For task ended! Duration: " + parallelFor.ToString());

            Console.WriteLine("Starting ProcessArrayChunkParallelFor task!");
            sw = Stopwatch.StartNew();
            ProcessArrayChunkParallelFor();
            TimeSpan parallelForChunks = sw.Elapsed;
            Console.WriteLine("\nProcessArrayChunkParallelFor task ended! Duration: " + parallelForChunks.ToString());

            Console.WriteLine("Starting RoundRobin task!");
            sw = Stopwatch.StartNew();
             ProcessArrayRoundRobinParallelFor();
            TimeSpan processRoundRobin = sw.Elapsed;
            Console.WriteLine("\nRoundRobin task ended! Duration: " + processRoundRobin.ToString());

            Console.WriteLine("Starting BalancedChunksParallelFor task!");
            sw = Stopwatch.StartNew();
            BalancedChunksParallelFor();
            TimeSpan balancedChunksParallelFor = sw.Elapsed;
            Console.WriteLine("\nBalancedChunksParallelFor task ended! Duration: " + balancedChunksParallelFor.ToString());

            Console.WriteLine("\nParallel.For speed-up: " + Math.Round(parallelFor.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");
            Console.WriteLine("\nChunk Array speed-up: " + Math.Round(parallelForChunks.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");
            Console.WriteLine("\nRoundRobin speed-up: " + Math.Round(processRoundRobin.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");
            Console.WriteLine("\nBalancedChunksParallelFor speed-up: " + Math.Round(balancedChunksParallelFor.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");

            Console.ReadLine();
        }
    }
}
