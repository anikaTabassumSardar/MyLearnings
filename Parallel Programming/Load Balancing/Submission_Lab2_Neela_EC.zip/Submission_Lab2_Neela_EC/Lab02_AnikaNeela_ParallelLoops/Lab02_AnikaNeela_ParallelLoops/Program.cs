﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace Lab02_AnikaNeela_ParallelLoops
{
    class Program
    {
        const int times = 3000;
        static double[] x = new double[times];
        static int cores = Environment.ProcessorCount;

        static void ProcessSquareElement(double e)
        {
            e = Math.Pow(e, 2);
            for (int y = 0; y < e; y++)
            {
                for (int x = 0; x < e; x++)
                {
                    e = (double)(e * Math.Sqrt(Math.Cos(1.0 / (e + 1)) + Math.Sin(1.0 / (e + 1))));
                }
            }
               

        }

        static void ProcessArray()
        {
            for (int i = 0; i < times; i++)
            {
                ProcessSquareElement(x[i]);
            }
        }

        static void ProcessArrayParallelFor()
        {
            Parallel.For(0, times, (int i) =>
            {
                //Console.WriteLine("i: " + i);
                ProcessSquareElement(x[i]);
            });
        }

        static void ProcessArrayChunkParallelFor()
        {
            Console.WriteLine("Work by ProcessArrayChunkParallelFor: ");
            Parallel.For(0, cores, (int chunk) =>
            {
                //Console.WriteLine("Chunk number for ProcessArrayChunkParallelFor(): " + chunk);
                int chunkSize = (int)(times / cores) + 1;
                Console.WriteLine("Percentage of Work for Chunk" + chunk + " " + Math.Round(((double)chunkSize/ times) * 100, 2) + "%");

                for (int i = chunk * chunkSize; i < (chunk + 1) * chunkSize && i < times; i++)
                {
                    // Console.WriteLine("Index number for ProcessArrayChunkParallelFor(): " + i);
                    ProcessSquareElement(x[i]);
                }
            }
            );
        }

        static void BalancedChunksParallelFor()
        {
            double doubleX = times / Math.Pow(cores * cores, 1 / 3.0);
            Console.WriteLine("Work by BalancedChunksParallelFor: ");
            Parallel.For(0, cores, (int chunk) =>
            {
                Console.WriteLine("Percentage of Work for Chunk" + chunk + ": " + Math.Round(doubleX / times, 2) * 100 + "%");
                double from = (doubleX * (Math.Pow(chunk, 1/2.0))/cores);
                double to = (doubleX * (Math.Pow((chunk + 1), 1 / 2.0))/ cores);
                for (double i = from; i < to && i < times; i++)
                    ProcessSquareElement(x[(int)i]);
            }
            );
        }

        static void BalancedSquareChunksParallelFor()
        {
            double doubleX = times / Math.Pow(cores * cores, 1 / 3.0);

            Console.WriteLine("Work by BalancedSquareChunksParallelFor: ");
            Parallel.For(0, cores, (int chunk) =>
            {
                Console.WriteLine("Percentage of Work for Chunk" + chunk + ": " + Math.Round(doubleX/ times, 2) * 100 + "%");
                double from = (doubleX * (Math.Pow(chunk, 1 / 3.0)) / cores);
                double to = (doubleX * (Math.Pow((chunk+1), 1 / 3.0)) / cores);
                for (double i = from; i < to && i < times; i++)
                    ProcessSquareElement(x[(int)i]);
            }
            );
        }

        static void ProcessArrayRoundRobinParallelFor()
        {
            Parallel.For(0, cores,
            (seed) =>

            {
                // Console.WriteLine("Seed: " + seed);
                for (int i = seed; i < times; i += cores) //i+= cores is the magic for robin
                {
                    // Console.WriteLine("i:" + i);
                    ProcessSquareElement(x[i]);
                }
            });
        }


        static void Main(string[] args)
        {
            Console.WriteLine("Starting sequential task!");
            var sw = Stopwatch.StartNew();
            ProcessArray();
            TimeSpan sequential = sw.Elapsed;
            Console.WriteLine("\nSequentialtask ended! Duration: " + sequential.ToString());

            Console.WriteLine("Starting Parallel.For task!");
            sw = Stopwatch.StartNew();
            ProcessArrayParallelFor();
            TimeSpan parallelFor = sw.Elapsed;
            Console.WriteLine("\nParallel.For task ended! Duration: " + parallelFor.ToString());

            Console.WriteLine("Starting ProcessArrayChunkParallelFor task!");
            sw = Stopwatch.StartNew();
            ProcessArrayChunkParallelFor();
            TimeSpan parallelForChunks = sw.Elapsed;
            Console.WriteLine("\nProcessArrayChunkParallelFor task ended! Duration: " + parallelForChunks.ToString());

            Console.WriteLine("Starting RoundRobin task!");
            sw = Stopwatch.StartNew();
            ProcessArrayRoundRobinParallelFor();
            TimeSpan processRoundRobin = sw.Elapsed;
            Console.WriteLine("\nRoundRobin task ended! Duration: " + processRoundRobin.ToString());

            Console.WriteLine("Starting BalancedChunksParallelFor task!");
            sw = Stopwatch.StartNew();
            BalancedChunksParallelFor();
            TimeSpan balancedChunksParallelFor = sw.Elapsed;
            Console.WriteLine("\nBalancedChunksParallelFor task ended! Duration: " + balancedChunksParallelFor.ToString());

            Console.WriteLine("Starting BalancedSquareChunksParallelFor task!");
            sw = Stopwatch.StartNew();
            BalancedSquareChunksParallelFor();
            TimeSpan balancedSquareChunksParallelFor = sw.Elapsed;
            Console.WriteLine("\nBalancedSquareChunksParallelFor task ended! Duration: " + balancedSquareChunksParallelFor.ToString());

            Console.WriteLine("\nParallel.For speed-up: " + Math.Round(parallelFor.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");
            Console.WriteLine("\nChunk Array speed-up: " + Math.Round(parallelForChunks.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");
            Console.WriteLine("\nRoundRobin speed-up: " + Math.Round(processRoundRobin.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");
            Console.WriteLine("\nBalancedChunksParallelFor speed-up: " + Math.Round(balancedChunksParallelFor.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");
            Console.WriteLine("\nBalancedSquareChunksParallelFor speed-up: " + Math.Round(balancedSquareChunksParallelFor.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");

            Console.ReadLine();
        }
    }
}
