﻿using System;
using System.Collections.Concurrent;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

//TODO Ensure that includeDelays uncheck works
namespace Lab8_FinalSubmission_AnikaNeela
{
    public partial class Form1 : Form
    {
        public const string ITEM_BUFFER_1_PREFIX = "Item Buffer 1: ";
        public const string ITEM_BUFFER_2_PREFIX = "Item Buffer 2: ";

        public static string currentPi = "";
        public static string prevPi = "";

        public static BigDecimal outPutValue; //updatedOutputValue
        public static BigDecimal partialSum = 0;
        public static BigDecimal prevCalcOfPi = 0;
        public static BigDecimal incrementForOptimizedMath = 0;

        public static bool stopBtnCLicked = false;
        public static bool cancelBtnClicked = false;
        public static bool resetBtnClicked = false;
        public static bool stepByStepBtnClicked = false;
        public static bool continuousBtnClicked = false;
        public static bool runOnce = false;
        public static bool needsToPrint = false;
        public static bool includeDelays = true;

        public static int n = 0; //number of iterations
        public static int incrementalValueFromStepByStep = -1; //number of iterations
        public static int totalItems = 100;
        public static int maxItems = 100;
        public static int consumerWait = 200;        //max random delay in the consumer stage
        public static int uniformDelays = 100;        
        public static int consumerProducerWait = 100; //max random delay in the consumer-producer stage

        public static CancellationTokenSource tokenSource;

        public BlockingCollection<BigDecimal> itemsBuffer1 = new BlockingCollection<BigDecimal>(maxItems);
        public BlockingCollection<BigDecimal> itemsBuffer2 = new BlockingCollection<BigDecimal>(maxItems);

        public Form1()
        {
            InitializeComponent();
        }

        private void continousBtn_Click(object sender, EventArgs e)
        {
            stepByStepBtn.Enabled = false; //disable step by step button
            stopBtn.Enabled = true;
            cancelBtn.Enabled = true;
            resetBtn.Enabled = true;

            tokenSource = new CancellationTokenSource();
            CancellationToken token = tokenSource.Token;
            continuousBtnClicked = true;
            resetBtnClicked = false;

            Producer theProducer = new Producer(itemsBuffer1, token);
            Consumer_Producer theConsumer_Producer1 = new Consumer_Producer(itemsBuffer1, itemsBuffer2);
            Consumer theConsumer = new Consumer(itemsBuffer2, token);
        }

        private void updateOnTick(object sender, EventArgs e)
        {
            FormattedDecimalPi();
            if (itemsBuffer1.Count != 0 || itemsBuffer2.Count != 0 || needsToPrint || !includeDelays)
            {
                if (!cancelBtnClicked)
                    ColorPi();
                needsToPrint = false;
            }
            PrintBuffers();
                   
        }

        private void ColorPi()
        {
            int i = 0;
            for (i = 0; i < currentPi.Length - 1; i++)
            {
                try
                {
                    if (currentPi[i] != prevPi[i])
                    {
                        break;
                    }
                }
                catch
                {
                    break;
                }

            }
            string correct = currentPi.Substring(0, i);
            string incorrect = currentPi.Substring(i);
            outputArea.AppendText(correct, Color.Black, true);
            outputArea.AppendText(incorrect, Color.Red, false);
            prevPi = currentPi;
        }

        private void PrintBuffers()
        {
            displayBuffer1.Text = ITEM_BUFFER_1_PREFIX + itemsBuffer1.Count;
            if (itemsBuffer1.Count == maxItems) //producer is throttled
            {
                displayBuffer1.BackColor = Color.Red;
            }
            else
            {
                displayBuffer1.BackColor = Color.Green;
            }
            displayBuffer2.Text = ITEM_BUFFER_2_PREFIX + itemsBuffer2.Count;
            if (itemsBuffer2.Count == 0) //consumer is blocked
            {
                displayBuffer2.BackColor = Color.Red;
            }
            else
            {
                displayBuffer2.BackColor = Color.Green;
            }
        }

        public void FormattedDecimalPi()
        {
           
            if (outPutValue.ToString().Contains("E"))
            {
                currentPi = outPutValue.ToString().Split('E').GetValue(0).ToString();
            }
            
            currentPi = currentPi.Substring(0, 1) + "." + currentPi.Substring(1); //adds the decimal point
        }
        
        private void resetBtn_Click(object sender, EventArgs e)
        {
            //enable all buttons
            continousBtn.Enabled = true;
            stepByStepBtn.Enabled = true;
            resetBtn.Enabled = false;
            stopBtn.Enabled = false;
            cancelBtn.Enabled = false;

            resetBtnClicked = true;
            incrementForOptimizedMath = 0;
            prevCalcOfPi = 0;
            outPutValue = 0;
            outputArea.Text = "";
            stopBtnCLicked = false;
            cancelBtnClicked = false;
            needsToPrint = false;
            partialSum = 0;
            n = 0;
            runOnce = false;
            itemsBuffer1.Dispose();
            itemsBuffer2.Dispose();
            itemsBuffer1 = new BlockingCollection<BigDecimal>(maxItems);
            itemsBuffer2 = new BlockingCollection<BigDecimal>(maxItems);
            continuousBtnClicked = false;
            stepByStepBtnClicked = false;
            incrementalValueFromStepByStep = -1;
            displayBuffer1.Text = ITEM_BUFFER_1_PREFIX;
            displayBuffer2.Text = ITEM_BUFFER_2_PREFIX;
            currentPi = "";
            prevPi = "";
            includeDelaysCheckbox.Checked = true;
        }

        private void numOfItems_Scroll(object sender, EventArgs e)
        {
            displayNumOfItems.Text = numOfItems.Value.ToString();
            totalItems = numOfItems.Value;
        }

        private void includeDelaysCheckbox_CheckedChanged(object sender, EventArgs e)
        {
            if (includeDelaysCheckbox.Checked)
            {
                includeDelays = true;
            }
            else
            {
                includeDelays = false;
            }
        }

        private void stopBtn_Click(object sender, EventArgs e)
        {
            stopBtnCLicked = true;
        }

        private void cancelBtn_Click(object sender, EventArgs e)
        {
            cancelBtnClicked = true;
        }

        private void stepByStepBtn_Click(object sender, EventArgs e)
        {
            stepByStepBtnClicked = true;
            resetBtn.Enabled = true;
            Interlocked.Increment(ref incrementalValueFromStepByStep);
            resetBtnClicked = false;
            runOnce = true;

            if (incrementalValueFromStepByStep == 0)
            {
                tokenSource = new CancellationTokenSource();
                CancellationToken token = tokenSource.Token;
                continuousBtnClicked = false;

                Producer theProducer = new Producer(itemsBuffer1, token);
                Consumer_Producer theConsumer_Producer1 = new Consumer_Producer(itemsBuffer1, itemsBuffer2);
                Consumer theConsumer = new Consumer(itemsBuffer2, token);
                
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            continousBtn.Enabled = true;
            stepByStepBtn.Enabled = true;
            resetBtn.Enabled = false;
            stopBtn.Enabled = false;
            cancelBtn.Enabled = false;
        }
    }

    class Producer
    {
        public Producer(BlockingCollection<BigDecimal> itemsBuffer, CancellationToken token)
        {
            object obj = new object();

            if (TheSemaphore == null) TheSemaphore = new SemaphoreSlim(10);
            //enter semaphore and decrement CurrentCount
            TheSemaphore.Wait();

            TheProducer = Task.Factory.StartNew(() =>
            {
                try
                {
                    if (!token.IsCancellationRequested)
                    {
                        if (Form1.continuousBtnClicked)
                        {
                            while (Form1.n <= Form1.totalItems)
                            {
                                

                                if (Form1.stopBtnCLicked) throw new Exception();

                                if (!Form1.includeDelays)
                                {
                                    Thread.Sleep(Form1.uniformDelays);
                                }
                                

                                int i = Form1.n;

                                Item item = new Item(i);
                                itemsBuffer.Add(item.Process());

                                if (Form1.continuousBtnClicked)
                                {
                                    Interlocked.Increment(ref Form1.n);
                                }

                            }
                        }else if (Form1.stepByStepBtnClicked)
                        {
                            int i = -1;
                            while(i <= Form1.totalItems)
                            {
                                if (Form1.runOnce)
                                {
                                    lock (obj)
                                    {
                                        i = Form1.incrementalValueFromStepByStep;
                                        Item item = new Item(i);
                                        Form1.n = i +1 ;  //updating n so that if the user clicks on "continuebtn", it can run as required
                                        itemsBuffer.Add(item.Process());
                                    }
                                    Form1.runOnce = false;
                                    Form1.needsToPrint = true;
                                }
                                
                            }
                        }
                    }
                }
                catch (OperationCanceledException) { }
                catch (Exception)
                {
                    if (Form1.stopBtnCLicked)
                    {
                        //phased shutdown, flush queues downstream
                        itemsBuffer.CompleteAdding(); 
                    }else if (Form1.cancelBtnClicked || Form1.resetBtnClicked)
                    {
                        //issue immediate cancellation request
                        Form1.tokenSource.Cancel();
                    }
                    else
                    {
                        throw;
                    }
                }

                //exit semaphore and increment CurrentCount
                TheSemaphore.Release();
                //set completion flag only if all producers finished job
                if (TheSemaphore.CurrentCount == 10 && Form1.cancelBtnClicked != true && Form1.stopBtnCLicked != true && !Form1.resetBtnClicked)
                    if(Form1.stepByStepBtnClicked != true)
                    {
                        itemsBuffer.CompleteAdding();
                    }
                    else
                    {
                        Form1.stepByStepBtnClicked = false;
                    }

            });
        }

        public Task TheProducer { get; set; }
        static SemaphoreSlim TheSemaphore = null;
    }

    class Consumer_Producer
    {
        public Consumer_Producer(BlockingCollection<BigDecimal> itemsSourceBuffer, BlockingCollection<BigDecimal> itemsDestinationBuffer)
        {
            object obj = new object();

            TheConsumer_Producer = Task.Factory.StartNew(() =>
            {
                if (TheSemaphore == null) TheSemaphore = new SemaphoreSlim(10);
                //enter semaphore and decrement CurrentCount
                TheSemaphore.Wait();
                //BigDecimal partialSum = 0;
                try
                {
                    if (!Form1.tokenSource.IsCancellationRequested)
                    {
                        foreach (BigDecimal item in itemsSourceBuffer.GetConsumingEnumerable())
                        {
                            if (Form1.cancelBtnClicked || Form1.resetBtnClicked) throw new Exception();

                            lock (obj)
                            {
                                Form1.partialSum += item;
                            }
                            itemsDestinationBuffer.Add(Form1.partialSum);

                            if (Form1.includeDelays)
                            {
                                Thread.Sleep(Form1.consumerProducerWait);
                            }
                            else
                            {
                                Thread.Sleep(Form1.uniformDelays);
                            }
                        }
                        
                    }
                }
                catch (OperationCanceledException) { }
                catch (Exception)
                {
                    //issue immediate cancellation request
                    Form1.tokenSource.Cancel();
                }

                //exit semaphore and increment CurrentCount
                TheSemaphore.Release();
                //set completion flag only if all producers finished job
                if (TheSemaphore.CurrentCount == 10 && Form1.cancelBtnClicked != true && Form1.stopBtnCLicked != true && !Form1.resetBtnClicked)
                    itemsDestinationBuffer.CompleteAdding();

            });
        }

        public Task TheConsumer_Producer { get; set; }
        static SemaphoreSlim TheSemaphore = null;
    }

    class Consumer
    {
        public Consumer(BlockingCollection<BigDecimal> itemsBuffer, CancellationToken token)
        {
            object obj = new object();

            TheConsumer = Task.Factory.StartNew(() =>
            {
                BigDecimal multiplicativeInverse = 0;

                try
                {
                    if (!Form1.tokenSource.IsCancellationRequested)
                    {
                        foreach (BigDecimal partialSum in itemsBuffer.GetConsumingEnumerable())
                        {
                            if (Form1.cancelBtnClicked || Form1.resetBtnClicked)  throw new Exception();

                            lock (obj)
                            {
                                multiplicativeInverse = 1 / partialSum;
                                Form1.outPutValue = multiplicativeInverse;
                            }

                            if (Form1.includeDelays)
                            {
                                Thread.Sleep(Form1.consumerWait);
                            }
                            else
                            {
                                Thread.Sleep(Form1.uniformDelays);
                            }
                        }
                    }                     
                }
                catch (OperationCanceledException) { }
                catch (Exception)
                {
                    //issue immediate cancellation request
                    Form1.tokenSource.Cancel();
                }
            });
        }

        public Task TheConsumer { get; set; }
    }

    class Item
    {
        public int data;
        public Item(int data)
        {
            this.data = data;
        }

        public BigDecimal Process()
        {
            object obj = new object();
            BigInteger partialFormulaForFact = 0;
            BigDecimal completeFormula = 0;
            BigDecimal part2 = 0;

            partialFormulaForFact = BigInteger.Pow(Factorial(2 * data) / (Factorial(data) * Factorial(data)), 3);
            part2 = (42 * data + 5) / new BigDecimal(BigInteger.Pow(2, 12 * data + 4), 0);
            completeFormula = new BigDecimal(partialFormulaForFact, 0) * part2;

            return completeFormula;
        }

        //Optimized Process
        ////public BigDecimal Process()
        ////{
        ////    object obj = new object();

        ////    BigInteger partialFormulaForFact = 0;
        ////    BigDecimal completeFormula = 0;
        ////    BigDecimal part2 = 0;

        ////    if (Form1.incrementForOptimizedMath <= 2)
        ////    {
        ////        lock (obj)
        ////        {
        ////            partialFormulaForFact = BigInteger.Pow(Factorial(2 * data) / (Factorial(data) * Factorial(data)), 3);
        ////            part2 = (42 * data + 5) / new BigDecimal(BigInteger.Pow(2, 12 * data + 4), 0);
        ////            completeFormula = new BigDecimal(partialFormulaForFact, 0) * part2;
        ////            lock (obj) Form1.prevCalcOfPi = (completeFormula);
        ////            Form1.incrementForOptimizedMath++;
        ////        }
        ////    }
        ////    else
        ////    {
        ////        lock (obj)
        ////        {
        ////            BigDecimal partialFormulaForFact1 = 0;
        ////            partialFormulaForFact1 = Form1.prevCalcOfPi * (2 * (2 * data - 1) / data);
        ////            part2 = (42 * data + 5) / new BigDecimal(BigInteger.Pow(2, 12 * 42* data-1 + 5), 0); 
        ////            completeFormula = partialFormulaForFact1 * part2;
        ////            Form1.prevCalcOfPi = (completeFormula);
        ////        }

        ////    }
        ////    return completeFormula;
        ////}

        private static BigInteger Factorial(long input)
        {
            if (input <= 1)
                return 1;
            return input * Factorial(input - 1);
        }
    }

    public static class RichTextBoxExtensions
    {
        public static void AppendText(this RichTextBox box, string text, Color color, bool firstText = true)
        {
            if (firstText)
            {
                box.Text = "";
            }
            box.SelectionStart = box.TextLength;
            box.SelectionLength = 0;

            box.SelectionColor = color;

            box.AppendText(text);

            box.SelectionColor = box.ForeColor;
        }
    }

}
