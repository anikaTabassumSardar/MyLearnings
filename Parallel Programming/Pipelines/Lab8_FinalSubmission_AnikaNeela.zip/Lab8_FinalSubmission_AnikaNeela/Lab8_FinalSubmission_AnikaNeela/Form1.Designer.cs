﻿namespace Lab8_FinalSubmission_AnikaNeela
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.outputArea = new System.Windows.Forms.RichTextBox();
            this.stepByStepBtn = new System.Windows.Forms.Button();
            this.continousBtn = new System.Windows.Forms.Button();
            this.resetBtn = new System.Windows.Forms.Button();
            this.stopBtn = new System.Windows.Forms.Button();
            this.cancelBtn = new System.Windows.Forms.Button();
            this.numOfItems = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.displayNumOfItems = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.includeDelaysCheckbox = new System.Windows.Forms.CheckBox();
            this.displayBuffer1 = new System.Windows.Forms.TextBox();
            this.displayBuffer2 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.numOfItems)).BeginInit();
            this.SuspendLayout();
            // 
            // outputArea
            // 
            this.outputArea.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.outputArea.Location = new System.Drawing.Point(43, 22);
            this.outputArea.Name = "outputArea";
            this.outputArea.ReadOnly = true;
            this.outputArea.Size = new System.Drawing.Size(428, 341);
            this.outputArea.TabIndex = 0;
            this.outputArea.Text = "";
            // 
            // stepByStepBtn
            // 
            this.stepByStepBtn.Location = new System.Drawing.Point(499, 22);
            this.stepByStepBtn.Name = "stepByStepBtn";
            this.stepByStepBtn.Size = new System.Drawing.Size(108, 53);
            this.stepByStepBtn.TabIndex = 1;
            this.stepByStepBtn.Text = "Step by Step";
            this.stepByStepBtn.UseVisualStyleBackColor = true;
            this.stepByStepBtn.Click += new System.EventHandler(this.stepByStepBtn_Click);
            // 
            // continousBtn
            // 
            this.continousBtn.Location = new System.Drawing.Point(499, 81);
            this.continousBtn.Name = "continousBtn";
            this.continousBtn.Size = new System.Drawing.Size(108, 53);
            this.continousBtn.TabIndex = 2;
            this.continousBtn.Text = "Continuous";
            this.continousBtn.UseVisualStyleBackColor = true;
            this.continousBtn.Click += new System.EventHandler(this.continousBtn_Click);
            // 
            // resetBtn
            // 
            this.resetBtn.Location = new System.Drawing.Point(499, 166);
            this.resetBtn.Name = "resetBtn";
            this.resetBtn.Size = new System.Drawing.Size(108, 53);
            this.resetBtn.TabIndex = 3;
            this.resetBtn.Text = "Reset";
            this.resetBtn.UseVisualStyleBackColor = true;
            this.resetBtn.Click += new System.EventHandler(this.resetBtn_Click);
            // 
            // stopBtn
            // 
            this.stopBtn.Location = new System.Drawing.Point(499, 251);
            this.stopBtn.Name = "stopBtn";
            this.stopBtn.Size = new System.Drawing.Size(108, 53);
            this.stopBtn.TabIndex = 4;
            this.stopBtn.Text = "Stop";
            this.stopBtn.UseVisualStyleBackColor = true;
            this.stopBtn.Click += new System.EventHandler(this.stopBtn_Click);
            // 
            // cancelBtn
            // 
            this.cancelBtn.Location = new System.Drawing.Point(499, 310);
            this.cancelBtn.Name = "cancelBtn";
            this.cancelBtn.Size = new System.Drawing.Size(108, 53);
            this.cancelBtn.TabIndex = 5;
            this.cancelBtn.Text = "Cancel";
            this.cancelBtn.UseVisualStyleBackColor = true;
            this.cancelBtn.Click += new System.EventHandler(this.cancelBtn_Click);
            // 
            // numOfItems
            // 
            this.numOfItems.Location = new System.Drawing.Point(43, 414);
            this.numOfItems.Maximum = 1000;
            this.numOfItems.Minimum = 100;
            this.numOfItems.Name = "numOfItems";
            this.numOfItems.Size = new System.Drawing.Size(185, 56);
            this.numOfItems.TabIndex = 6;
            this.numOfItems.Value = 100;
            this.numOfItems.Scroll += new System.EventHandler(this.numOfItems_Scroll);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(54, 394);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "Number of Items";
            // 
            // displayNumOfItems
            // 
            this.displayNumOfItems.BackColor = System.Drawing.SystemColors.Menu;
            this.displayNumOfItems.Location = new System.Drawing.Point(234, 414);
            this.displayNumOfItems.Name = "displayNumOfItems";
            this.displayNumOfItems.ReadOnly = true;
            this.displayNumOfItems.Size = new System.Drawing.Size(53, 22);
            this.displayNumOfItems.TabIndex = 8;
            this.displayNumOfItems.Text = "100";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 200;
            this.timer1.Tick += new System.EventHandler(this.updateOnTick);
            // 
            // includeDelaysCheckbox
            // 
            this.includeDelaysCheckbox.AutoSize = true;
            this.includeDelaysCheckbox.Checked = true;
            this.includeDelaysCheckbox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.includeDelaysCheckbox.Location = new System.Drawing.Point(57, 476);
            this.includeDelaysCheckbox.Name = "includeDelaysCheckbox";
            this.includeDelaysCheckbox.Size = new System.Drawing.Size(122, 21);
            this.includeDelaysCheckbox.TabIndex = 9;
            this.includeDelaysCheckbox.Text = "Include Delays";
            this.includeDelaysCheckbox.UseVisualStyleBackColor = true;
            this.includeDelaysCheckbox.CheckedChanged += new System.EventHandler(this.includeDelaysCheckbox_CheckedChanged);
            // 
            // displayBuffer1
            // 
            this.displayBuffer1.Location = new System.Drawing.Point(383, 403);
            this.displayBuffer1.Multiline = true;
            this.displayBuffer1.Name = "displayBuffer1";
            this.displayBuffer1.ReadOnly = true;
            this.displayBuffer1.Size = new System.Drawing.Size(183, 42);
            this.displayBuffer1.TabIndex = 10;
            this.displayBuffer1.Text = "Item Buffer 1: ";
            // 
            // displayBuffer2
            // 
            this.displayBuffer2.Location = new System.Drawing.Point(383, 455);
            this.displayBuffer2.Multiline = true;
            this.displayBuffer2.Name = "displayBuffer2";
            this.displayBuffer2.ReadOnly = true;
            this.displayBuffer2.Size = new System.Drawing.Size(183, 42);
            this.displayBuffer2.TabIndex = 11;
            this.displayBuffer2.Text = "Item Buffer 2: ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 525);
            this.Controls.Add(this.displayBuffer2);
            this.Controls.Add(this.displayBuffer1);
            this.Controls.Add(this.includeDelaysCheckbox);
            this.Controls.Add(this.displayNumOfItems);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.numOfItems);
            this.Controls.Add(this.cancelBtn);
            this.Controls.Add(this.stopBtn);
            this.Controls.Add(this.resetBtn);
            this.Controls.Add(this.continousBtn);
            this.Controls.Add(this.stepByStepBtn);
            this.Controls.Add(this.outputArea);
            this.Name = "Form1";
            this.Text = "Pipelines";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.numOfItems)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox outputArea;
        private System.Windows.Forms.Button stepByStepBtn;
        private System.Windows.Forms.Button continousBtn;
        private System.Windows.Forms.Button resetBtn;
        private System.Windows.Forms.Button stopBtn;
        private System.Windows.Forms.Button cancelBtn;
        private System.Windows.Forms.TrackBar numOfItems;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox displayNumOfItems;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.CheckBox includeDelaysCheckbox;
        private System.Windows.Forms.TextBox displayBuffer1;
        private System.Windows.Forms.TextBox displayBuffer2;
    }
}

