﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace Submission_Lab7_Neela
{
    class Tree<T>
    {
        public int Index;
        public int Data;
        public Tree<T> Left;
        public Tree<T> Right;
        public Random randomNumber = new Random();
        public static List<int> uniqueList = new List<int>();

        public Tree(int from, int to)
        {
            int middle = (from + to) / 2;
            this.Index = middle;
            do
            {
                this.Data = randomNumber.Next(from, to * 10);

            } while (uniqueList.Contains(this.Data));
            uniqueList.Add(this.Data);

            if (from == to) return;
            Left = new Tree<T>(from, middle - 1);
            Right = new Tree<T>(middle + 1, to);
        }

    }
    class Program
    {
        static CancellationTokenSource tokenSource = new CancellationTokenSource();
        static ParallelOptions options = new ParallelOptions { CancellationToken = tokenSource.Token };
        static int foundIndex = -1;

        static int TaskParallelSearch<T>(Tree<T> root, Action<Tree<T>, int> theAction, int dataToBeSearched, int depth)
        {
            int foundIndex = -1;
            if (root == null) return foundIndex;
            if (depth > 0)
            {
                Task.Factory.StartNew(
                () =>
                {
                    if (options.CancellationToken.IsCancellationRequested)
                    {
                        //tokenSource.Dispose();
                        return;
                    }
                    else
                    {
                        TaskParallelSearch(root.Left, theAction, dataToBeSearched, depth-1);
                        theAction(root, dataToBeSearched);
                        TaskParallelSearch(root.Right, theAction, dataToBeSearched, depth-1);
                    }
                }, tokenSource.Token
                , TaskCreationOptions.AttachedToParent, TaskScheduler.Current);
            }
            else
            {
                TaskParallelSearch(root.Left, theAction, dataToBeSearched, 0);
                theAction(root, dataToBeSearched);
                TaskParallelSearch(root.Right, theAction, dataToBeSearched, 0);
            }
            return foundIndex;
        }

        static void theAction(Tree<int> root, int dataToBeSearched)
        {
            Console.WriteLine("Data is: " + root.Data + " at Index: " + root.Index + " Thread ID=" + Thread.CurrentThread.ManagedThreadId);
            if (root.Data == dataToBeSearched)
            {
                foundIndex = root.Index;
                tokenSource.Cancel();
            }
        }

        static void Main(string[] args)
        {
            int from = 1;
            int to = 15;
            int depth = (int)Math.Log(Environment.ProcessorCount, 2) + 1;

            Console.WriteLine("Starting TaskParallelSearch!");
            ////Retrieve a random value inserted into the tree in order to search it
            Random random = new Random();
            int randomIndexFromList = random.Next(to);
            var sw = Stopwatch.StartNew();
            Task.WaitAll(Task.Factory.StartNew(() => foundIndex = TaskParallelSearch<int>(new Tree<int>(from, to), theAction, Tree<int>.uniqueList[randomIndexFromList], depth)));
            TimeSpan taskParallelSearch = sw.Elapsed;
            if (foundIndex == -1)
            {
                Console.WriteLine();
                Console.WriteLine("Could not find value " + Tree<int>.uniqueList[randomIndexFromList]);
                Console.WriteLine();
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Found " + Tree<int>.uniqueList[randomIndexFromList] + " at Index: " + foundIndex);
                Console.WriteLine();
            }
            Console.WriteLine("Ending TaskParallelSearch!");
            Console.WriteLine("TaskParallelSearch ended! Duration: " + taskParallelSearch.ToString());

            Console.ReadLine();
        }
    }
}
