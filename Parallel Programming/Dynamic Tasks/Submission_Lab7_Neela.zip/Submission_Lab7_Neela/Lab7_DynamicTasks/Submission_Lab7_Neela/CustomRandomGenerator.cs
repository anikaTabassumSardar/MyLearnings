﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace Submission_Lab7_Neela
//{
//    class CustomRandomGenerator
//    {
//        private int listSize;
//        private static List<int> arrayList = new List<int>();
//        private static Random random = new Random();
//        public CustomRandomGenerator(int size, int from, int to)
//        {
//            this.listSize = size;
//            buildList(from, to);
//        }

//        public int getNext(int from, int to)
//        {
//            return arrayList;
            
//        }

//        public void buildList(int from, int to)
//        {
//            int uniqueRandomNumber;
//            for (int i = 0; i < listSize; i++)
//            {
//                do
//                {
//                    uniqueRandomNumber = random.Next(from, to) * 3;

//                } while (arrayList.Contains(uniqueRandomNumber));

//                arrayList.Add(uniqueRandomNumber);
//            }
//        }
//    }
//}
