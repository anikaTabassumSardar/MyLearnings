﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
//Added for the parallcurrentItem features
using System.Threading.Tasks;
// Added for the Stopwatch
using System.Diagnostics;
using System.Threading;

public class MyList : IEnumerable<byte>, IEnumerator<byte> //TODO Declare interfaces implemented by class
{
    List<byte> l { get; set; }
    public MyList(int size)
    {
        byte[] x = new byte[size];
        for (int i = 0; i < size; i++) x[i] = (byte)i;
        l = x.ToList<byte>();
    }

    //implement IEnumerable interface
    //TODO define private IEnumerator member and initialize with null
    private IEnumerator listEnumerator = null;
    public IEnumerator GetEnumerator()
    {
        //TODO get the enumerator of the underlying List<byte> and store in private member
        this.listEnumerator = l.GetEnumerator();
        return this;
    }
    //implement IEnumerable<byte> interface
    IEnumerator<byte> IEnumerable<byte>.GetEnumerator()
    {
        //TODO get the enumerator of the underlying List<byte> and store in private member
        this.listEnumerator = l.GetEnumerator();
        return (IEnumerator<byte>)this;
    }

    //implement IEnumerator interface
    //make 'this' able to enumerate itself by implementing Reset(),MoveNext() and Current
    public void Reset()
    {
        //TODO call the Reset() method of the underlying List<byte>
        this.listEnumerator.Reset();
    }
    public bool MoveNext()
    {
        Console.WriteLine("MoveNext() Called");
        //TODO call the MoveNext() method of the underlying List<byte>
        int n = 0;
        Thread.SpinWait(n);
        bool ret = this.listEnumerator.MoveNext();
        return ret;
    }

    public object Current
    {
        get
        {
            return this.listEnumerator.Current; 
        }
    }

    byte IEnumerator<byte>.Current
    {
        get
        {
            return (byte)this.listEnumerator.Current;
        }
    }
    //end IEnumerable interface

    public byte[] ToArray()
    {
        return l.ToArray<byte>();
    }
    
    #region IDisposable Support
    private bool disposedValue = false; 

    protected virtual void Dispose(bool disposing)
    {
        if (!disposedValue)
        {
            if (disposing) ;
            disposedValue = true;
        }
    }

    void IDisposable.Dispose()
    {
        Dispose(true);
    }
    #endregion
}

class Program
{
    const int times = 10; //10000000;
    static MyList l;

    static void DoWork(byte currentItem)
    {
        byte item = (byte)(Math.Cos(Math.Sqrt(currentItem * currentItem * currentItem * currentItem)) +
                Math.Sin(Math.Sqrt(currentItem * currentItem * currentItem * currentItem)));
    }

    static void Processforeach()
    {
        //Sequential foreach
        foreach(byte b in l)
        {
            DoWork(b);
        }
    }

    static void NonIndexedParallelForEach()
    {
        //Parallel.ForEach
        Parallel.ForEach(l, (currentItem) => DoWork(currentItem));
    }

    static void IndexedParallelForEach()
    {
        //Indexed Parallel.ForEach
        Parallel.ForEach(l.ToArray(), (currentItem) => DoWork(currentItem));
    }

    static void Main(string[] args)
    {
        l = new MyList(times);
        Console.WriteLine("Starting sequential task!");
        var sw = Stopwatch.StartNew();
        Processforeach();
        TimeSpan sequential = sw.Elapsed;
        Console.WriteLine("\nSequential task ended! Duration: " + sw.Elapsed.ToString());

        l = new MyList(times);
        Console.WriteLine("Starting Non-Indexed Parallel.ForEach task!");
        sw = Stopwatch.StartNew();
        NonIndexedParallelForEach();
        TimeSpan parallelForEach = sw.Elapsed;
        Console.WriteLine("\nNon-Indexed Parallel.ForEach task ended! Duration: " + sw.Elapsed.ToString());

        l = new MyList(times);
        Console.WriteLine("Starting IndexedParallel.ForEach task!");
        sw = Stopwatch.StartNew();
        IndexedParallelForEach();
        TimeSpan indexedparallelForEach = sw.Elapsed;
        Console.WriteLine("\nIndexed Parallel.For task ended! Duration: " + sw.Elapsed.ToString());

        Console.WriteLine("\nNon-Indexed Parallel.ForEach speed-up: " + Math.Round(parallelForEach.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");
        Console.WriteLine("\nIndexed Parallel.For speed-up: " + Math.Round(indexedparallelForEach.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");
        Console.ReadLine();
    }
}

