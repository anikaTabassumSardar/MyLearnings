﻿using System;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;

namespace Lab6_Futures
{
    class Program
    {
        int a = 0;
        static int F1(int a)
        {
            var b = a + 3;
            SpinWait.SpinUntil(() => { return false; }, 3000);
            Console.WriteLine(Thread.CurrentThread.ManagedThreadId + " -> Function F1(" + a + ")");
            return b;
        }

        static int F2(int a)
        {
            var c = a + 3;
            SpinWait.SpinUntil(() => { return false; }, 3000);
            Console.WriteLine(Thread.CurrentThread.ManagedThreadId + " -> Function F2(" + a + ")");
            return c;
        }

        static int F3(int c)
        {
            var e = c + 1;
            SpinWait.SpinUntil(() => { return false; }, 1000);
            Console.WriteLine(Thread.CurrentThread.ManagedThreadId + " -> Function F3(" + c + ")");
            return e;
        }

        static int F4(int a)
        {
            var d = a + 1;
            SpinWait.SpinUntil(() => { return false; }, 1000);
            Console.WriteLine(Thread.CurrentThread.ManagedThreadId + " -> Function F4(" + a + ")");
            return d;
        }

        static int F5(int d)
        {
            var f = d + 2;
            SpinWait.SpinUntil(() => { return false; }, 2000);
            Console.WriteLine(Thread.CurrentThread.ManagedThreadId + " -> Function F5(" + d + ")");
            return f;
        }

        static int F6(int d)
        {
            var g = d + 1;
            SpinWait.SpinUntil(() => { return false; }, 1000);
            Console.WriteLine(Thread.CurrentThread.ManagedThreadId + " -> Function F6(" + d + ")");
            return g;
        }

        static int F7(int f, int g)
        {
            var h = Math.Max(f, g) + 2;
            SpinWait.SpinUntil(() => { return false; }, 2000);
            Console.WriteLine(Thread.CurrentThread.ManagedThreadId + " -> Function F7(" + f + ", " + g + ")");
            return h;
        }

        static int F8(int b, int e)
        {
            var j = Math.Max(b, e) + 4;
            SpinWait.SpinUntil(() => { return false; }, 4000);
            Console.WriteLine(Thread.CurrentThread.ManagedThreadId + " -> Function F8(" + b + ", " + e + ")");
            return j;
        }

        static int F9(int e, int h)
        {
            var i = Math.Max(e ,h) + 3;
            SpinWait.SpinUntil(() => { return false; }, 3000);
            Console.WriteLine(Thread.CurrentThread.ManagedThreadId + " -> Function F9(" + e + ", " + h + ")");
            return i;
        }

        static int Sequential(int a)
        {
            var b = F1(a);
            var c = F2(a);
            var e = F3(c);
            var d = F4(a);
            var f = F5(d);
            var g = F6(d);
            var h = F7(f, g);
            var j = F8(b, e);
            var i = F9(e, h);
            var result = i + j;
            return result;
        }

        static int Futures_WithF9AsMain(int a)
        {
            ////futures
            Task<int> f2_f3 = Task.Factory.StartNew<int>(() => F3(F2(a)));
            Task<int> f1_f8 = Task.Factory.StartNew<int>(() => F8(F1(a), f2_f3.Result));
            Task<int> f4_f5 = Task.Factory.StartNew<int>(() => F5(F4(a)));
            Task<int> f4_f6_f7 = Task.Factory.StartNew<int>(() => F7(F6(F4(a)), f4_f5.Result));

            int f9 = F9(f2_f3.Result, f4_f6_f7.Result);
            int end = f1_f8.Result + f9;
            return end;
        }

        static void Main(string[] args)
        {
            var sw = Stopwatch.StartNew();
            Console.WriteLine("Starting Sequential!");
            int result = Sequential(0);
            Console.WriteLine("Sequential ended! Result=" + result + "; Duration: " + sw.Elapsed.ToString());
            Console.WriteLine();

            sw = Stopwatch.StartNew();
            Console.WriteLine("Starting Futures_WithF9AsMain!");
            result = Futures_WithF9AsMain(0);
            Console.WriteLine("Futures_WithF9AsMain ended! Result=" + result + "; Duration: " + sw.Elapsed.ToString());
            Console.WriteLine();
        }
    }
}
