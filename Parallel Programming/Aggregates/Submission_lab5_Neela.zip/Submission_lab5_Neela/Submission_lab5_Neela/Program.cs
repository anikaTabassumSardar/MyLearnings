﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace Submission_lab5_Neela
{
    class Program
    {
        private const int ARRAY_LENGTH = 100000000;
        private static int cores = System.Environment.ProcessorCount;
        private static readonly int[] vector_A = Enumerable.Range(30, ARRAY_LENGTH).ToArray(); //array of ARRAY_LENGTH integers starts from 30
        private static readonly int[] vector_B = Enumerable.Range(2, ARRAY_LENGTH).ToArray(); //array of ARRAY_LENGTH integers starts from 2

        static double Serial_EuclidianDistance()
        {
            double tempHold = 0;

            for(int i = 0; i < vector_A.Length; i++)
            {
                Thread.SpinWait(10);
                tempHold += Math.Pow((vector_A[i] - vector_B[i]), 2);
            }

            return Math.Sqrt(tempHold);
        }

        static double ParallelForEachWithPartitioner_EuclidianDistance()
        {
            double summedDistance = 0.0;
            object obj = new object();
            int chunkSize = ARRAY_LENGTH % cores == 0 ? ARRAY_LENGTH / cores : ARRAY_LENGTH / cores + 1;
            Parallel.ForEach(Partitioner.Create(0, ARRAY_LENGTH, chunkSize),
           //initialization delegate
           () => 0.0,
           //body delegate
           (range, status, localDistance) =>
           {
               for (int i = range.Item1; i < range.Item2; i++)
               {
                   Thread.SpinWait(10);
                   localDistance += (long) Math.Pow((vector_A[i] - vector_B[i]), 2);
               }
               return localDistance;
           },
           //aggregation delegate
           localsum => { lock (obj) summedDistance += localsum; });

            return Math.Sqrt(summedDistance);
        }

        static double TaskInstanceWithLocks()
        {
            Task[] theTasks = new Task[cores];
            int times = vector_A.Length;
            double result = 0;
            object obj = new object();

            for (int chunk = 0; chunk < cores; chunk++)
            {
                int temp = chunk;
                int chunkOrigin = times % cores == 0 ? chunk * times / cores : chunk * (times / cores + 1);
                int chunkSize = Math.Min(times % cores == 0 ? times / cores : times / cores + 1, times - chunkOrigin);

                theTasks[chunk] = new Task(
                    () =>
                    {
                        double localDistance = 0;
                        for (int index = chunkOrigin; index < chunkOrigin + chunkSize; index++)
                        {
                            Thread.SpinWait(10);
                            localDistance += (long)Math.Pow((vector_A[index] - vector_B[index]), 2);
                        }
                        if (temp > 0)
                            theTasks[temp - 1].Wait();
                        lock (obj) result += localDistance;
                }
                );
            }

            
            Parallel.For(0, cores, chunk => { /*Thread.SpinWait(10 * (cores - chunk));*/ theTasks[chunk].Start(); });
            Task.WaitAll(theTasks); //or Wait(theTasks[cores - 1]);
            return Math.Sqrt(result);
        }

        static double TaskInstanceWithoutLocks()
        {
            Task[] theTasks = new Task[cores];
            int times = vector_A.Length;
            double finalResult = 0;
            double[] resultArray = new double[cores];

            for (int chunk = 0; chunk < cores; chunk++)
            {
                int temp = chunk;
                int chunkOrigin = times % cores == 0 ? chunk * times / cores : chunk * (times / cores + 1);
                int chunkSize = Math.Min(times % cores == 0 ? times / cores : times / cores + 1, times - chunkOrigin);

                theTasks[chunk] = new Task(
                    () =>
                    {
                        double localDistance = 0;
                        for (int index = chunkOrigin; index < chunkOrigin + chunkSize; index++)
                        {
                            Thread.SpinWait(10);
                            localDistance += (long)Math.Pow((vector_A[index] - vector_B[index]), 2); 
                        }
                        if (temp > 0)
                            theTasks[temp - 1].Wait();
                        resultArray[temp] = localDistance;
                    }
                );
            }

            Parallel.For(0, cores, chunk => { /*Thread.SpinWait(10 * (cores - chunk));*/  theTasks[chunk].Start(); });
            Task.WaitAll(theTasks); //or Wait(theTasks[cores - 1]);

            for(int i = 0; i < cores; i++)
            {
                finalResult += resultArray[i];
            }
            return Math.Sqrt(finalResult);
        }

        static void Main(string[] args)
        {
            /**Serial**/
            var sw = Stopwatch.StartNew();
            Console.WriteLine("Starting Serial!");
            double result = Math.Round(Serial_EuclidianDistance(), 2);
            Console.WriteLine("Serial ended! Duration: " + sw.Elapsed.ToString());
            Console.WriteLine("Serial result is: " + result);
            TimeSpan sequential = sw.Elapsed;
            Console.WriteLine();
            Console.WriteLine();

            /**ParallelForEachWithPartitioner**/
            sw = Stopwatch.StartNew();
            Console.WriteLine("Starting Parallel.ForEach() with a Partitioner!");
            double result1 = Math.Round(ParallelForEachWithPartitioner_EuclidianDistance(),2);
            Console.WriteLine("Parallel.ForEach() with a Partitioner ended! Duration: " + sw.Elapsed.ToString());
            Console.WriteLine("Parallel.ForEach() with a Partitioner result is: " + result1);
            TimeSpan parallelForEachWithPartitioner = sw.Elapsed;
            Console.WriteLine();
            Console.WriteLine();

            /**TaskInstanceWithLocks**/
            sw = Stopwatch.StartNew();
            Console.WriteLine("Starting TaskInstanceWithLocks!");
            double result2 = Math.Round(TaskInstanceWithLocks(), 2);
            Console.WriteLine("TaskInstanceWithLocks ended! Duration: " + sw.Elapsed.ToString());
            Console.WriteLine("TaskInstanceWithLocks result is: " + result2);
            TimeSpan taskInstanceWithLocks = sw.Elapsed;
            Console.WriteLine();
            Console.WriteLine();

            /**TaskInstanceWithoutLocks**/
            sw = Stopwatch.StartNew();
            Console.WriteLine("Starting TaskInstanceWithoutLocks!");
            double result3 = Math.Round(TaskInstanceWithoutLocks(), 2);
            Console.WriteLine("TaskInstanceWithoutLocks ended! Duration: " + sw.Elapsed.ToString());
            Console.WriteLine("TaskInstanceWithoutLocks result is: " + result3);
            TimeSpan taskInstanceWithoutLocks = sw.Elapsed;
            Console.WriteLine();
            Console.WriteLine("**********************************************************************************");

            Console.WriteLine("\nParallel.ForEach() with a Partitioner speed-up: " + Math.Round(parallelForEachWithPartitioner.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");
            Console.WriteLine("\nTaskInstanceWithLocks speed-up: " + Math.Round(taskInstanceWithLocks.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");
            Console.WriteLine("\nTaskInstanceWithoutLocks speed-up: " + Math.Round(taskInstanceWithoutLocks.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");

            Console.ReadLine();
        }

        
    }
}
