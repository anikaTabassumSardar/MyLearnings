﻿using System;
using System.Collections.Generic;
//Added for the parallel features
using System.Threading.Tasks;
using System.Threading;
// Added for the Stopwatch
using System.Diagnostics;

class Program
{
    const int times = 100000000;
    const int waitTime = 100;
    static int cores = Environment.ProcessorCount;
    static int[] searchArray = new int[times];
    static int value = 99780005;

    static int SequentialSearch(int[] theArray, int value)
    {
        return DirectComparisonSearch(value); 
    }

    static void RandomizeIntInArray()
    {
        Random rd = new Random(); // creating Random object
        for (int i = searchArray.Length - 1; i > 0; i--)
        {
            int index = rd.Next(i + 1);
            // Simple swap
            int a = searchArray[index];
            searchArray[index] = searchArray[i];
            searchArray[i] = a;
        }
    }
    static int DirectComparisonSearch(int value)
    {
        for(int i = 0; i < searchArray.Length; i++)
        {
            Thread.SpinWait(waitTime);
            if (searchArray[i] == value)
            {
                return i;
             
            }
        }

        return -1;
    }

    static int DirectComparisonSearch_WithChunk(int value, int chunkOrigin, int chunkSize)
    {
        for (int i = chunkOrigin; i < chunkSize + chunkOrigin; i++)
        {
            Thread.SpinWait(waitTime);
            if (searchArray[i] == value)
            {
                
                return i;
            }
        }

        return -1;
    }

    static int ParallelForStop()
    {
        int temp = -1; 
        Parallel.For(0, searchArray.Length, (int index, ParallelLoopState state) =>
        {
            Thread.SpinWait(waitTime);
            if (searchArray[index] == value)
            {
               
                temp = index;
                state.Stop();
            }
        }
        );

        return temp;
    }

    static int Parallel_Task()
    {
        List<Task<int>> theTasks = new List<Task<int>>();
        CancellationTokenSource tokenSource = new CancellationTokenSource();
        CancellationToken token = tokenSource.Token;

        for (int i = 0; i < cores; i++)
        {
            int temp = i;
            int chunkOrigin = times % cores == 0 ? i * times / cores : i * (times / cores + 1);
            int chunkSize = Math.Min(times % cores == 0 ? times / cores : times / cores + 1, times - chunkOrigin);
            
            theTasks.Add(Task.Factory.StartNew<int>(
                () =>
                {
                  
                    //if (temp > 0) Thread.SpinWait(times);

                    int index = DirectComparisonSearch_WithChunk(value, chunkOrigin, chunkSize);
                    //throw exception, i.e. terminate if someone else requested cancellation
                    //token.ThrowIfCancellationRequested();
                    return index;
                },
                token));
        }

        //get the index of the Task that found value, if any
        bool found = false;
        int resultIndex = -1;
        while (theTasks.Count > 0 && !found)
        {
            int winnerTaskIndex = Task.WaitAny(theTasks.ToArray());
            resultIndex = theTasks[winnerTaskIndex].Result;
            if (resultIndex > 0)
            {
                found = true;
                //successfully found value, so request cancellation of all remaining tasks
                tokenSource.Cancel();
            }
            else
                theTasks.RemoveAt(winnerTaskIndex);
        }

        //return the index in the array of the value found as returned by winner task
        return resultIndex;
    }

    static int ChunkParallelForWithStop()
    {
        int temp = -1;
        Parallel.For(0, cores, (int chunk, ParallelLoopState state) =>
        {
            int chunkSize = (int)(times / cores);//+ 1; //ensures to avoid truncation so that we are overestimating when it is odd and get decimal which eventually gets truncated
            for (int i = chunk * chunkSize; i < (chunk + 1) * chunkSize && i < times; i++)
            {
                Thread.SpinWait(waitTime);
                if (searchArray[i] == value)
                {
                    temp = i;
                    state.Stop();
                }
            }
        }
        );

        return temp;
    }

    static int ParallelForWithPartitioner()
    {
        int temp = -1;
        Parallel.ForEach(System.Collections.Concurrent.Partitioner.Create(0, times),
                        ( Tuple<int, int> range, ParallelLoopState state) =>
                        {
                            for (int i = range.Item1; i < range.Item2; i++)
                            {
                                Thread.SpinWait(waitTime);
                                if (searchArray[i] == value)
                                {
                                    temp = i;
                                    state.Stop();
                                }
                            }
                        }
                    );

        return temp;
    }

    /****EXTRA CREDIT*******/
    static int ParallelTask_Search_EXTRA_CREDIT()
    {
        int resultIndex = -1;
        List<Action> theTasks = new List<Action>();
        CancellationTokenSource tokenSource = new CancellationTokenSource();
        ParallelOptions options = new ParallelOptions { CancellationToken = tokenSource.Token };

        for (int i = 0; i < cores; i++)
        {
            int temp = i;
            int chunkOrigin = times % cores == 0 ? i * times / cores : i * (times / cores + 1);
            int chunkSize = Math.Min(times % cores == 0 ? times / cores : times / cores + 1, times - chunkOrigin);

            theTasks.Add(() =>
            {
                int ratio = 100;
                for (int ii = 0; ii < ratio; ii++)
                {
                    //Thread.SpinWait(times / cores / ratio);
                    //if (temp < cores - 1) Thread.SpinWait(times / ratio);
                    options.CancellationToken.ThrowIfCancellationRequested();
                    //if (options.CancellationToken.IsCancellationRequested) return;
                }

                int index = DirectComparisonSearch_WithChunk(value, chunkOrigin, chunkSize);
                if (index > 0)
                {
                    resultIndex = index;
                    tokenSource.Cancel();
                }
            });
        }
        try
        {
            Parallel.Invoke(options, theTasks.ToArray());
        }
        catch (OperationCanceledException ocex) { }
        finally
        {
            tokenSource.Dispose();
        }

        //return the index in the array of the value found as returned by winner task
        return resultIndex;
    }

    static void Main(string[] args)
    {
        for (int i = 0; i < times; i++) searchArray[i] = i;
        RandomizeIntInArray(); //randomize the array values

        var sw = Stopwatch.StartNew();
        Console.WriteLine("Starting SequentialSearch search!");
        int sequentialIndex = SequentialSearch(searchArray, value);
        Console.WriteLine("SequentialSearch ended! Duration: " + sw.Elapsed.ToString());
        Console.WriteLine("SequentialSearch index is: " + sequentialIndex);
        Console.WriteLine(sequentialIndex >= 0 ? "Value is: " + searchArray[sequentialIndex] : "Value Not Found!");
        TimeSpan sequential = sw.Elapsed;

        sw = Stopwatch.StartNew();
        Console.WriteLine("\nStarting Parallel.For() with Stop() search task!");
        int parallelIndex = ParallelForStop();
        Console.WriteLine("Parallel.For() with Stop() search ended! Duration: " + sw.Elapsed.ToString());
        Console.WriteLine("Parallel.For() with Stop() index is: " + parallelIndex);
        Console.WriteLine(parallelIndex >= 0 ? "Value is: " + searchArray[parallelIndex] : "Value Not Found!");
        TimeSpan parallel = sw.Elapsed;

        sw = Stopwatch.StartNew();
        Console.WriteLine("\nStarting Parallel_Task search task!");
        int taskIndex = Parallel_Task();
        Console.WriteLine("Parallel_Task search ended! Duration: " + sw.Elapsed.ToString());
        Console.WriteLine("Parallel_Task index is: " + taskIndex);
        Console.WriteLine(parallelIndex >= 0 ? "Value is: " + searchArray[taskIndex] : "Value Not Found!");
        TimeSpan task = sw.Elapsed;

        sw = Stopwatch.StartNew();
        Console.WriteLine("\nStarting Parallel.For() with chunks & Stop() search task!");
        int parallelForWithChunkIndex = ChunkParallelForWithStop();
        Console.WriteLine("Parallel.For() with chunks & Stop() search ended! Duration: " + sw.Elapsed.ToString());
        Console.WriteLine("Parallel.For() with chunks & Stop() index is: " + parallelForWithChunkIndex);
        Console.WriteLine(parallelIndex >= 0 ? "Value is: " + searchArray[parallelForWithChunkIndex] : "Value Not Found!");
        TimeSpan parallelForWithChunk = sw.Elapsed;

        sw = Stopwatch.StartNew();
        Console.WriteLine("\nStarting Parallel.Foreach with Stop search task!");
        int parallelForEachIndex = ParallelForWithPartitioner();
        Console.WriteLine("Parallel.Foreach with Stop search ended! Duration: " + sw.Elapsed.ToString());
        Console.WriteLine("Parallel.Foreach with Stop is: " + parallelForEachIndex);
        Console.WriteLine(parallelIndex >= 0 ? "Value is: " + searchArray[parallelForEachIndex] : "Value Not Found!");
        TimeSpan parallelForEach = sw.Elapsed;

        sw = Stopwatch.StartNew();
        Console.WriteLine();
        Console.WriteLine("*********ParallelTask_Search_EXTRA_CREDIT CREDIT**********");
        Console.WriteLine("\nStarting ParallelSearch with Parallel.Invoke search task!");
        int extra_credit_index = ParallelTask_Search_EXTRA_CREDIT();
        Console.WriteLine("ParallelSearch with Parallel.Invoke search ended! Duration: " + sw.Elapsed.ToString());
        Console.WriteLine("ParallelSearch with Parallel.Invoke with Parallel Invoke is: " + extra_credit_index);
        Console.WriteLine(parallelIndex >= 0 ? "Value is: " + searchArray[extra_credit_index] : "Value Not Found!");
        TimeSpan extra_credit = sw.Elapsed;

        Console.WriteLine();
        Console.WriteLine("*******Comparisons of Speedup*********");
        Console.WriteLine("\nParallel.For() with Stop() search speed-up: " + Math.Round(parallel.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");
        Console.WriteLine("\nParallel_Task search speed-up: " + Math.Round(task.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");
        Console.WriteLine("\nParallel.For() with chunks & Stop() speed-up: " + Math.Round(parallelForWithChunk.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");
        Console.WriteLine("\nParallel.Foreach with Stop() speed-up: " + Math.Round(parallelForEach.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");
        Console.WriteLine("\nParallelTask_Search_EXTRA_CREDIT with Parallel.Invoke speed-up: " + Math.Round(extra_credit.TotalMilliseconds / sequential.TotalMilliseconds * 100, 2) + "%");

    }
}
